%%
profile on

run('main.m')

profile off
profsave
profile view
