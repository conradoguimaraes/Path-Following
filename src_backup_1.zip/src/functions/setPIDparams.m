threshold = d;

% Kp = 5 %0.0709
% Kd = 10 %0.467
% Kp = 5.0700


% Kp = 2
% Kd = 9.9300
% Ki = 0.005

% Ki = 0

Kp = 2.7
Kd = 5.93
Ki = 0.1

custo = 0;