function phrase = helloWorld()
    fprintf("hello world!\n")
    phrase = "hello world"
end