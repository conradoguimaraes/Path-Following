function startingPoint(x,y)
    global Pxatual Pyatual
    
%     Pxatual = 20 + 2*round(randn,2)  %Pxinicial
%     Pyatual = 11 + 2*round(randn,2)  %Pyinicial
%     Pxatual = 15;
%     Pyatual = 12;
    Pxatual = x;
    Pyatual = y;
end