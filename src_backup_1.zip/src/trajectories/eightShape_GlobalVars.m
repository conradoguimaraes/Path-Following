%Trajectory Parameters:
global Cx1 Cy1
global Cx2 Cy2
global R1 R2

global delta
global theta1
global theta2

%-------------------------------------------------
%Trajectory Path:
global Xarc1 Yarc1
global Xarc2 Yarc2

global Dx1 Dy1
global Dx2 Dy2
global Ex1 Ey1
global Ex2 Ey2

global X_reta1 Y_reta1
global X_reta2 Y_reta2

%-------------------------------------------------

%Fixed Vectors:
global reta1Xvector
global reta1Yvector

global reta2Xvector
global reta2Yvector


%-------------------------------------------------
%Points Vectors:
global PontosX
global PontosY


%-------------------------------------------------
%Starting Point:
global Pxatual
global Pyatual