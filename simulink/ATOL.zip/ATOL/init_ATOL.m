clear all; 
clc
close all;

%Parameters
Ro= 1.2;                                % Fluid Density
vw=0;                                   % Fluid Velocity [m s-1]
%m=0.7;
m=1;                                    % Mass [Kg]
%A=0.28;
A=1;                                   % Wing Reference Area of Kite [m^2]
g=9.8;                                  % Gravidade

% R, Beta, Phi
% rmin=100;                             % Comprimento mínimo do cabo
% rmax=500;                             % Comprimento máximo do cabo
rmax = 50;


%Initial Conditions
r0= 10;                                 % R inicial
% beta0=beta_star+delta_beta;           % Beta inicial
% phi0= phi_star;                       % Phi inicial
beta0=0;                                % Beta inicial
phi0= 0;                                % Phi inicial
dr0=0;                                  % Velocidade inicial em r
dbeta0=0*pi/180;                        % Velocidade inicial em beta 
dphi0=1*pi/180;                         % Velocidade inicial em phi

at = 0;
alpha = 10*pi/180;

sim = sim('dynamics')
Kite = sim.Kite;

x=linspace(0,300,10);  

[xs,ys,zs] = sphere;            %# Makes a 21-by-21 point sphere
xs = xs(11:end,6:16);           %# Keep top 11 x points
ys = ys(11:end,6:16);           %# Keep top 11 y points
zs = zs(11:end,6:16);           %# Keep top 11 z points
rs = 10;                        %# A radius value
% % 
% hold all; plot3(y(1,1), y(1,2), y(1,3),'+r')

figure(1)
xlabel('X')
ylabel('Y')
zlabel('Z')
hold all
lightGrey = 0.9*[1 1 1]; % It looks better if the lines are lighter
surface(rs.*xs,rs.*ys,rs.*zs,'FaceColor', 'none','EdgeColor',lightGrey)
axis equal;            %# Make the scaling on the x, y, and z axes equal
plot3(Kite(:,1), Kite(:,2), Kite(:,3))
plot3(Kite(1,1), Kite(1,2), Kite(1,3),'+r')