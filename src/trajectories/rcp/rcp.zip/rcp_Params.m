% Cx1 = 10;
% Cy1 = 15;
% Cx2 = 50;
% Cy2 = 15;
% R1 = 10;
% R2 = 10;

% Cx1 = 10;
% Cy1 = 15;
% Cx2 = 50;
% Cy2 = 15;
% R1 = 10;
% R2 = 10;

% delta = 0;

% theta1 = (pi/2 - delta) : 0.0001 : ((3*pi)/2 + delta);
% theta2 = -(pi/2 + delta) : 0.0001 : (pi/2 + delta);